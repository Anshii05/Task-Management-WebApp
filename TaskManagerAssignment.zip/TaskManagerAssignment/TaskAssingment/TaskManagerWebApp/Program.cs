﻿using TaskManagerWebApp.DataLayer;
using ServiceLayer;
using DataLayer;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSession();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<UserRepository>();
builder.Services.AddScoped<TaskService>();
builder.Services.AddScoped<TaskRepository>();
builder.Services.AddScoped<AssignedTaskService>();
builder.Services.AddScoped<AssignedTaskRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

app.UseSession(); // Must be before Authorization
app.UseAuthorization();

app.MapRazorPages();

// Redirect "/" to the Login page
app.MapGet("/", (HttpContext context) =>
{
    return Results.Redirect("/Login");
});

app.Run();
