using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using ServiceLayer;
using Task = Core.BusinessObject.Task;
using Core.BusinessObject;

namespace TaskManagerWebApp.Pages.Admin
{
    [BindProperties]
    public class ManageTaskModel : PageModel
    {
        public List<Task> TaskList { get; set; }
        public List<Core.BusinessObject.User> UserList { get; set; }
        public int TaskId { get; set; }
        [Required(ErrorMessage = "Title is required.")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Description is required.")]
        public string Description { get; set; }
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }
        [Required(ErrorMessage = "Remarks is required.")]
        public string Remarks { get; set; }
        public List<string> AssignedUserIds { get; set; }

        private readonly UserService _userService;
        private readonly AssignedTaskService _assignedTaskService;
        private readonly TaskService _taskService;
        /// <summary>
        /// Constructor to Initialize the page model with services
        /// </summary>
        /// <param name="userService"></param>
        public ManageTaskModel(UserService userService, AssignedTaskService assignedTaskService, TaskService taskService)
        {
            _userService = userService;
            _assignedTaskService = assignedTaskService;
            _taskService = taskService;
        }
        /// <summary>
        /// Method to get the tasklist and userlist
        /// </summary>
        public void OnGet()
        {
            TaskService _taskService = new TaskService();
            TaskList = _taskService.GetAll();
            UserList = _userService.GetAll();
        }

        /// <summary>
        /// OnPost method to add task
        /// </summary>
        /// <returns></returns>
        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                TaskList = _taskService.GetAll();
                return Page();
            }

            AssignedUserIds = AssignedUserIds ?? new List<string>();

            var currentuserId = (int)HttpContext.Session.GetInt32("UserId");
            var currentuserName = HttpContext.Session.GetString("UserName");

            var newTask = new Task
            {
                Title = Title,
                Description = Description,
                DueDate = DueDate,
                Remarks = Remarks,
                AssignedUserIds = string.Join(",", AssignedUserIds),
                CreatedOn = DateTime.Now,
                UpdatedOn = DateTime.Now,
                CreatedById = currentuserId,
                CreatedByName = currentuserName,
                UpdatedById = currentuserId,
                UpdatedByName = currentuserName,
            };
            _taskService.Add(newTask);
            int taskId = _taskService.GetAll().Where(x => x.Title == newTask.Title).FirstOrDefault().TaskId;

            // Add entries to AssignedTask for each assigned user
            foreach (var uid in AssignedUserIds)
            {
                if (int.TryParse(uid, out int assignedUserId))
                {
                    Core.BusinessObject.User user=_userService.GetById(assignedUserId);
                    var assignedTask = new AssignedTask
                    {
                        TaskId = taskId,
                        UserId = assignedUserId,
                        UserName = user.FirstName + " " + user.LastName,
                        Title = Title,
                        Description = Description,
                        DueDate = DueDate,
                        Status = (int)Core.BusinessObject.Constants.TaskStatus.NotStarted,
                        Remarks = Remarks,
                        CreatedOn = DateTime.Now,
                        UpdatedOn = DateTime.Now,
                        CreatedById = currentuserId,
                        CreatedByName = currentuserName,
                        UpdatedById = currentuserId,
                        UpdatedByName = currentuserName
                    };

                    _assignedTaskService.Add(assignedTask);
                }
            }
            TempData["SuccessMessage"] = "Task added successfully.";
            return RedirectToPage();
        }
        /// <summary>
        /// Method to edit task
        /// </summary>
        /// <returns></returns>
        public IActionResult OnPostEdit()
        {
            if (ModelState.IsValid)
            {
                AssignedUserIds = AssignedUserIds ?? new List<string>();

                var currentuserId = (int)HttpContext.Session.GetInt32("UserId");
                var currentuserName = HttpContext.Session.GetString("UserName");

                var updatedTask = new Task
                {
                    TaskId = TaskId,
                    Title = Title,
                    Description = Description,
                    DueDate = DueDate,
                    Remarks = Remarks,
                    AssignedUserIds = string.Join(",", AssignedUserIds),
                    UpdatedOn = DateTime.Now,
                    UpdatedById = currentuserId,
                    UpdatedByName = currentuserName
                };

                // Update Task
                _taskService.Update(updatedTask);

                // Get existing AssignedTasks for this TaskId
                List<AssignedTask> existingAssignedTasks = _assignedTaskService.GetByTaskId(TaskId);

                // Update or Insert AssignedTasks
                foreach (var uid in AssignedUserIds)
                {
                    if (int.TryParse(uid, out int assignedUserId))
                    {
                        Core.BusinessObject.User user = _userService.GetById(assignedUserId);
                        var existing = existingAssignedTasks.FirstOrDefault(x => x.UserId == assignedUserId);
                        if (existing != null)
                        {
                            // Update existing
                            existing.Title = Title;
                            existing.Description = Description;
                            existing.DueDate = DueDate;
                            existing.Remarks = Remarks;
                            existing.UpdatedById = currentuserId;
                            existing.UpdatedByName = currentuserName;
                            existing.UpdatedOn = DateTime.Now;

                            _assignedTaskService.Update(existing);
                        }
                        else
                        {
                            // Insert new
                            var assignedTask = new AssignedTask
                            {
                                TaskId = TaskId,
                                UserId = assignedUserId,
                                UserName = user.FirstName + " " + user.LastName,
                                Title = Title,
                                Description = Description,
                                DueDate = DueDate,
                                Status = (int)Core.BusinessObject.Constants.TaskStatus.NotStarted,
                                Remarks = Remarks,
                                CreatedOn = DateTime.Now,
                                UpdatedOn = DateTime.Now,
                                CreatedById = currentuserId,
                                CreatedByName = currentuserName,
                                UpdatedById = currentuserId,
                                UpdatedByName = currentuserName
                            };

                            _assignedTaskService.Add(assignedTask);
                        }
                    }
                }

                
                foreach (var oldAssigned in existingAssignedTasks)
                {
                    if (!AssignedUserIds.Contains(oldAssigned.UserId.ToString()))
                    {
                        _assignedTaskService.DeleteByTaskIdAndUserId(TaskId, oldAssigned.UserId);
                    }
                }

                TempData["SuccessMessage"] = "Task updated successfully.";
                return RedirectToPage();
            }
            TempData["AlertMessage"] = "Error updating Task";
            return Page();
        }

        /// <summary>
        /// Method to delete task
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult OnGetDelete(int id)
        {
            TaskService _taskService = new TaskService();

            // Delete all assigned tasks related to this task
            _assignedTaskService.DeleteByTaskId(id);

            // Delete the main task
            _taskService.Delete(id);
            TempData["AlertMessage"] = "Task deleted successfully.";
            return new JsonResult(new { success = true });
        }

        /// <summary>
        /// Method to get task by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult OnGetById(int id)
        {
            TaskService _taskService = new TaskService();
            var task = _taskService.GetById(id);
            return new JsonResult(new
            {
                taskId = task.TaskId,
                title = task.Title,
                description = task.Description,
                dueDate = task.DueDate.ToString("yyyy-MM-dd"),
                assignedUserIds = task.AssignedUserIds,
                remarks = task.Remarks
            });
        }
    }
}