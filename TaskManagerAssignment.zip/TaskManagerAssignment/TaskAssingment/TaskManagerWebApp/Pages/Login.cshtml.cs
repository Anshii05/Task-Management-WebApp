using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ServiceLayer;

namespace TaskManagerWebApp.Pages
{
    [BindProperties]
    public class LoginModel : PageModel
    {
        private readonly UserService _userService;

        public LoginModel(UserService userService)
        {
            _userService = userService;
        }

        public string Email { get; set; }
        public string Password { get; set; }
        public string Mode { get; set; } // "user" or "admin"
        public string Message { get; set; }
        public void OnGet()
        {
            
        }
        /// <summary>
        /// OnPost method
        /// </summary>
        /// <returns></returns>
        public IActionResult OnPost()
        {
            HttpContext.Session.Clear();
            var user = _userService.ValidateUser(Email, Password);

            if (user != null)
            {
                HttpContext.Session.SetString("UserEmail", user.Email);
                HttpContext.Session.SetInt32("UserId", user.UserId);

                Core.BusinessObject.User currentUser = _userService.GetAll().FirstOrDefault(x => x.Email == user.Email);
                if (currentUser != null)
                {
                    HttpContext.Session.SetInt32("Type", currentUser.Type);
                    HttpContext.Session.SetString("UserName", currentUser.FirstName);

                    if (currentUser.Type == 0) // admin
                        return RedirectToPage("/Admin/Index");
                    else if (currentUser.Type == 1) // user
                        return RedirectToPage("/User/Index");
                }
            }

            Message = "Invalid email or password.";
            return Page();
        }

    }
}
