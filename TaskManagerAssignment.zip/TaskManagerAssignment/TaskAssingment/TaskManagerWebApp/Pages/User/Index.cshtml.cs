using Core.BusinessObject;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ServiceLayer;

namespace TaskManagerWebApp.Pages
{
    public class IndexModel : PageModel
    {
        public string currentUserName { get; set; }
        public int currentUserId { get; set; }
        public int totalTasks { get; set; }
        public int inprogressTasks { get; set; }
        public int completedTasks { get; set; }
        public int notstartedTasks { get; set; }
        private readonly ILogger<IndexModel> _logger;
        private readonly AssignedTaskService _assignedTaskService;
        public IndexModel(ILogger<IndexModel> logger,AssignedTaskService assignedTaskService)
        {
            _logger = logger;
            _assignedTaskService = assignedTaskService;
        }

        public void OnGet()
        {
            currentUserId = (int)HttpContext.Session.GetInt32("UserId");
            currentUserName = HttpContext.Session.GetString("UserName");
            List<AssignedTask> assignedTaskList = _assignedTaskService.GetByUserId(currentUserId).ToList();
            notstartedTasks = assignedTaskList.Where(x => x.Status == (int)Core.BusinessObject.Constants.TaskStatus.NotStarted).Count();
            inprogressTasks = assignedTaskList.Where(x => x.Status == (int)Core.BusinessObject.Constants.TaskStatus.InProgress).Count();
            completedTasks = assignedTaskList.Where(x => x.Status == (int)Core.BusinessObject.Constants.TaskStatus.Completed).Count();
            totalTasks = assignedTaskList.Count();
        }
    }
}
