using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ServiceLayer;
using Core.BusinessObject;
using Task = Core.BusinessObject.Task;

namespace TaskManagerWebApp.Pages.User
{
    [BindProperties]
    public class UpdateTaskModel : PageModel
    {
        public List<AssignedTask> AssignedTaskList { get; set; }

        public int TaskId { get; set; }
        public int Status { get; set; }
        private readonly AssignedTaskService _assignedTaskService;

        public UpdateTaskModel(AssignedTaskService assignedTaskService)
        {
            _assignedTaskService = assignedTaskService;
        }
        /// <summary>
        /// OnGet Method for task list
        /// </summary>
        public void OnGet()
        {
            var currentUserId = (int)HttpContext.Session.GetInt32("UserId");
            AssignedTaskList = _assignedTaskService.GetByUserId(currentUserId);
        }
        /// <summary>
        /// Method to update task
        /// </summary>
        /// <returns></returns>
        public IActionResult OnPostEdit()
        {
            var currentUserId = (int)HttpContext.Session.GetInt32("UserId");
            var currentUserName = HttpContext.Session.GetString("UserName");
            List<AssignedTask> assignedTaskList = _assignedTaskService.GetByTaskId(TaskId);
            AssignedTask assignedTask = assignedTaskList.Where(x => x.UserId == currentUserId).FirstOrDefault();
            if (assignedTask != null)
            {
                assignedTask.Status = Status;
                assignedTask.UpdatedOn = DateTime.Now;
                assignedTask.UpdatedById = currentUserId;
                assignedTask.UpdatedByName = currentUserName;
            }
            _assignedTaskService.Update(assignedTask);
            return RedirectToPage();
        }
        /// <summary>
        /// Method to get task by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult OnGetById(int id)
        {
            var currentUserId = (int)HttpContext.Session.GetInt32("UserId");
            List<AssignedTask> assignedTaskList = _assignedTaskService.GetByTaskId(id);
            AssignedTask assignedTask = assignedTaskList.Where(x => x.UserId == currentUserId).FirstOrDefault();

            return new JsonResult(new
            {
                taskId = assignedTask.TaskId,
                status = assignedTask.Status
            });
        }
    }
}
