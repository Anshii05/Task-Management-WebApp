using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Core.BusinessObject;
using ServiceLayer;
namespace TaskManagerWebApp.Pages
{
    [BindProperties]
    public class UserListModel : PageModel
    {
        public List<Core.BusinessObject.User> Users { get; set; }
        private readonly UserService _userService;
        public int Type { get; set; }
        public AddUserModel NewUser { get; set; }

        public class AddUserModel
        {
            [Required(ErrorMessage = "First Name is required.")]
            public string FirstName { get; set; }

            [Required(ErrorMessage = "Last Name is required.")]
            public string LastName { get; set; }

            [Required(ErrorMessage = "Email is required.")]
            [EmailAddress(ErrorMessage = "Enter a valid email address.")]
            public string Email { get; set; }

            [Required(ErrorMessage = "Password is required.")]
            [MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
            public string Password { get; set; }

            [Required(ErrorMessage = "User Type is required.")]
            public int Type { get; set; }
        }
        /// <summary>
        /// Constructor to initialize page model with userservice for handling user-related functionality
        /// </summary>
        /// <param name="userService"></param>
        public UserListModel(UserService userService)
        {
            _userService = userService;
        }
        /// <summary>
        /// OnGet method
        /// </summary>
        public void OnGet()
        {
            Users = _userService.GetAll();
        }
        /// <summary>
        /// Method to get user by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult OnGetGetUserById(int id)
        {
            var user = _userService.GetById(id);

            if (user != null)
            {
                return new JsonResult(new
                {
                    userId = user.UserId,
                    firstName = user.FirstName,
                    lastName = user.LastName,
                    email = user.Email,
                    type=user.Type,
                    createdon=user.CreatedOn,
                    createdby=user.CreatedBy,
                    updatedon=user.UpdatedOn,
                    updatedby=user.UpdatedBy
                });
            }

            return new JsonResult(null);
        }
        /// <summary>
        /// Method to add user
        /// </summary>
        /// <returns></returns>
        public IActionResult OnPostAddUser()
        {
            if (!ModelState.IsValid)
            {
                TempData["AlertMessage"] = "Please correct the highlighted errors.";
                return Page();
            }

            var user = new Core.BusinessObject.User
            {
                FirstName = NewUser.FirstName,
                LastName = NewUser.LastName,
                Email = NewUser.Email,
                Password = NewUser.Password,
                Type = NewUser.Type,
                CreatedOn = DateTime.UtcNow,
                CreatedBy = HttpContext.Session.GetString("UserEmail") ?? "System"
            };

            new UserService().Add(user);
            TempData["SuccessMessage"] = "User added successfully.";
            return RedirectToPage();
        }
        /// <summary>
        /// Method to delete user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult OnGetDeleteUser(int id)
        {
            if(id == default(int))
            {
                TempData["AlertMessage"] = "Error deleting user";
            }
            UserService _userService = new UserService();

            _userService.Delete(id);
            TempData["AlertMessage"] = "User deleted successfully.";
            return new JsonResult(new { success = true });
        }
        /// <summary>
        /// Method to update user
        /// </summary>
        /// <param name="id"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public JsonResult OnGetUpdateUser(int id, string firstName, string lastName, string email,string password,int type)
        {
            var user = _userService.GetById(id);
            if (user != null)
            {
                user.FirstName = firstName;
                user.LastName = lastName;
                user.Email = email;
                if (password != null)
                {
                    user.Password = password;
                }
                else
                {
                    user.Password = user.Password;
                }
                user.Type = type;
                user.UpdatedOn = DateTime.UtcNow;
                user.UpdatedBy = HttpContext.Session.GetString("UserEmail") ?? "System";

                _userService.Update(user);
                TempData["SuccessMessage"] = "User updated successfully.";
                return new JsonResult(new { success = true });
            }
            return new JsonResult(new { success = false });
        }


    }
}
